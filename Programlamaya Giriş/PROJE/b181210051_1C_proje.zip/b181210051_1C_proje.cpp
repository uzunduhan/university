/****************************************************************************
**					SAKARYA �N�VERS�TES�
**			B�LG�SAYAR VE B�L���M B�L�MLER� FAK�LTES�
**				B�LG�SAYAR M�HEND�SL��� B�L�M�
**				  PROGRAMLAMAYA G�R��� DERS�
**
**				�DEV NUMARASI....: proje �devi
**				��RENC� ADI......: Duhan UZUN
**				��RENC� NUMARASI.: B181210051
**				DERS GRUBU����...: C Grubu
****************************************************************************/

#include <iostream>
#include <Windows.h>

using namespace std;

enum YON // yon
{
	YON_SAG = 1,
};

struct mermihucre // merminin �zellikleri
{
	int x;
	int y;

	YON yon;
	char karakter;
};

const int sahneyukseklik = 20;
const int sahnegenislik = 70;

char sahne[sahnegenislik][sahneyukseklik];
char tuslar[256];

int ucakucu = 8;
int asag�s�n�r = 16;
int yukar�s�n�r = 3;
int dusman = 6;
int mermiadet = 1;

mermihucre mermi[90000000];


void gotoxy(int, int); // kursorun yerini ayarl�yor

void sahneyiCiz(); //sahneyi �iziyor

void sinirlariOlustur(); // s�n�rlar� olu�turuyor

void kursorGizle(); // kursoru gizliyor

void sahneyiTemizle(); // sahneyi temizliyor

void klavyeoku(char tuslar[]); // klavye girileni okuyor
 
void ucakolustur(); // ucak olu�turuyor

void klavyekontrol(); // klavyeyi kontrol ediyor

void mermiyisahneyeyerlestir(); // mermiyi sahneye yerle�tiriyor

void mermiyiatesle(); // mermiyi hareket ettiriyor

void mermiekle(); // mermi say�s�n� �o�alt�yor

void dusmanolustur(); // dusman olusturuyor

int i,m,t,l = 80;

int main()
{
	kursorGizle();

	ucakolustur();

	while (true) // e�er do�ruysa i�lemleri ger�ekle�tir
	{

		sahneyiTemizle();

		sinirlariOlustur();

		ucakolustur();

		klavyekontrol();

		
		mermiyisahneyeyerlestir();

		dusmanolustur();
		
		mermiyiatesle();

		gotoxy(0, 0);

		sahneyiCiz();

		Sleep(0);

		if (i <= 0) // dusman�n h�cresi 0 noktas�na geldi�inde ba�a al�yor 
		{
			i+=sahnegenislik; // dusman�n h�cresi 0 noktas�na geldi�inde ba�a al�yor
		}

		if (m <= 0)
		{
			m += sahnegenislik; // dusman�n h�cresi 0 noktas�na geldi�inde ba�a al�yor
		}

		if (t <= 0)
		{
			t += sahnegenislik; // dusman�n h�cresi 0 noktas�na geldi�inde ba�a al�yor
		}
        
		if (l <= 0)
		{
			l += sahnegenislik; // dusman�n h�cresi 0 noktas�na geldi�inde ba�a al�yor
		}
	}

	cin.get();
}

void gotoxy(int x, int y)
{
	COORD koordinat;
	koordinat.X = x;
	koordinat.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), koordinat);
}

void sahneyiCiz()
{
	for (int y = 0; y < sahneyukseklik; y++) //sahnenin yuksekli�i kadar artt�r�yor 
	{
		for (int x = 0; x < sahnegenislik; x++) //sahnenin geni�li�i kadar artt�r�yor
		{
			cout << sahne[x][y]; // sahneyi ekrana yazd�r�yor
		}
		cout << endl;
	}
}

void sahneyiTemizle()
{
	for (int y = 0; y < sahneyukseklik; y++)  //sahnenin yuksekli�i kadar artt�r�yor
	{
		for (int x = 0; x < sahnegenislik; x++) //sahnenin geni�li�i kadar artt�r�yor
		{
			sahne[x][y] = ' '; ;  //sahneyi temizliyor
		}
	}
}

void sinirlariOlustur()
{
	for (int x = 0; x < sahnegenislik; x++) //sahnenin geni�li�i kadar artt�r�yor
	{
		sahne[x][0] = 219;
		sahne[x][sahneyukseklik - 1] = 219; // en s�n�r�n� �iziyor
	}

	for (int y = 0; y < sahneyukseklik; y++)  //sahnenin yuksekli�i kadar artt�r�yor
	{
		sahne[0][y] = 219;
		sahne[sahnegenislik - 1][y] = 219; //boy s�n�r�n� �iziyor
	}
}

void kursorGizle()
{
	HANDLE out = GetStdHandle(STD_OUTPUT_HANDLE);

	CONSOLE_CURSOR_INFO		cursorInfo;

	GetConsoleCursorInfo(out, &cursorInfo);
	cursorInfo.bVisible = false;
	SetConsoleCursorInfo(out, &cursorInfo);
}

void klavyeoku(char tuslar[])
{
	for (int x = 0; x < 256; x++)
	{
		tuslar[x] = (char)(GetAsyncKeyState(x) >> 8);
	}
}

void ucakolustur()
{
	sahne[1][ucakucu - 2] = 219;
	sahne[2][ucakucu - 1] = 219;
	sahne[3][ucakucu] = 219;
	sahne[2][ucakucu + 1] = 219;
	sahne[1][ucakucu + 2] = 219;
}

void mermiekle()
{
	int x = mermi[mermiadet - 1].x; //bir �nceki merminin x ini al�yor
	int y = mermi[mermiadet - 1].y; //bir �nceki merminin y sini al�yor
	YON yon = mermi[mermiadet - 1].yon; //bir �nceki merminin y�n�n� al�yor
	char kar = mermi[mermiadet - 1].karakter; //bir �nceki merminin karakterini al�yor

	switch (mermi[mermiadet - 1].yon) // bir �nceki merminin y�n� neyse ona g�re hareket ediyor
	{
	case YON_SAG:
		x = 4;
		y = ucakucu;

		break;
	}

	mermi[mermiadet].x = x; // al�nan x i yeni mermiye aktar�yor
	mermi[mermiadet].y = y; // al�nan y yi yeni mermiye aktar�yor
	mermi[mermiadet].yon = yon; // al�nan y�n� yeni mermiye aktar�yor
	mermi[mermiadet].karakter = kar; // al�nan  karakteri yeni mermiye aktar�yor
	mermiadet++; // her d�ng� d�nd���nde mermi say�s�n� artt�r�yor
}
void mermiyisahneyeyerlestir()
{
	for (int k = 1; k < mermiadet; k++) // b�t�n mermileri tar�yor(ka� mermi var)
	{
		int x = mermi[k].x; // sahneye x ini yerle�tiriyor
		int y = mermi[k].y; // sahneye y sini yerle�tiriyor
		sahne[x][y] = 175; // merminin karakteri

		if (i-1==x && y == 7) // e�er merminin bir ucu d��manla kar��la��rsa d��man� sahne d���na at
		{
			i = sahnegenislik + 10;
		}

		if (i - 1 == x && y == 6) // e�er merminin bir ucu d��manla kar��la��rsa d��man� sahne d���na at
		{
			i = sahnegenislik+10;
		}

		if (m - 1 == x && y == 10) // e�er merminin bir ucu d��manla kar��la��rsa d��man� sahne d���na at
		{
			m = sahnegenislik + 10;
		}

		if (m - 1 == x && y == 11) // e�er merminin bir ucu d��manla kar��la��rsa d��man� sahne d���na at
		{
			m = sahnegenislik + 10;
		}

		if (t - 1 == x && y == 4) // e�er merminin bir ucu d��manla kar��la��rsa d��man� sahne d���na at
		{
			t = sahnegenislik + 10;
		}

		if (t - 1 == x && y == 5) // e�er merminin bir ucu d��manla kar��la��rsa d��man� sahne d���na at
		{
			t = sahnegenislik + 10;
		}

		if (l - 1 == x && y == 12) // e�er merminin bir ucu d��manla kar��la��rsa d��man� sahne d���na at
		{
			l = sahnegenislik + 10;
		}

		if (l - 1 == x && y == 13) // e�er merminin bir ucu d��manla kar��la��rsa d��man� sahne d���na at
		{
			l = sahnegenislik + 10;
		}

	}	
}

void mermiyiatesle()
{
	for (int i = 0; i < mermiadet; i++)  // b�t�n mermileri tar�yor(ka� mermi var)
	{

		switch (mermi[i].yon) // merminin y�n�n�n ne oldu�u kararla�t�r�l�yor
		{
		case YON_SAG:
		 if (mermi[i].x < sahnegenislik) // e�er sa�a do�ruysa x ini artt�r�yor
		  mermi[i].x++;
		  break;
		}
	}

	for (int i = 0; i < mermiadet; i++) // b�t�n mermileri tar�yor(ka� mermi var)
	{
		mermi[i + 1].yon = mermi[i].yon; //eski mermi y�n�n� yeni mermiye aktar�yor
	}
}

void dusmanolustur()
{
	int gen = 10;
	if (i>0) //e�er d��man ba�lang�� koordinat�nda de�ilse d��man� olu�turuyor
	{
		sahne[i][gen-4] = 187, sahne[i][gen-3] = 188, sahne[i - 1][gen-3] = 200, sahne[i - 1][gen-4] = 201;
	}

    if (m > 0) //e�er d��man ba�lang�� koordinat�nda de�ilse d��man� olu�turuyor
	{
		sahne[m][gen] = 187, sahne[m][gen+1] = 188, sahne[m - 1][gen+1] = 200, sahne[m  - 1][gen] = 201;
	}

	if (t > 0) //e�er d��man ba�lang�� koordinat�nda de�ilse d��man� olu�turuyor
	{
		sahne[t][gen-6] = 187, sahne[t][gen -5] = 188, sahne[t-1][gen -5] = 200, sahne[t-1][gen-6] = 201;
	}

	if (l> 0) //e�er d��man ba�lang�� koordinat�nda de�ilse d��man� olu�turuyor
	{
		sahne[l][gen + 2] = 187, sahne[l][gen +3] = 188, sahne[l - 1][gen +3] = 200, sahne[l - 1][gen +2] = 201;
	}

	i -= 2; m -= 3; t -= 1; l -= 2;
}

void klavyekontrol()
{
	klavyeoku(tuslar);

	if (tuslar['W'] != 0)
	{
		if (ucakucu > yukar�s�n�r) // e�er w ya bas�ld�ysa u�a�� yukar� ��kar�yor
		{
			ucakucu -= 1;
		}
	}

	if (tuslar['S'] != 0) // e�er s ye bas�ld�ysa u�a�� a�a�� indiriyor
	{
		if (ucakucu < asag�s�n�r)
		{
			ucakucu += 1;
		}
	} 

	if (tuslar['B'] != 0) // e�er b ye bas�ld�ysa ilk mermiyi ate�liyor
	{
		mermiadet = 1;

		mermi[0].x = 4;
		mermi[0].y = ucakucu;
		mermi[0].yon = YON_SAG;
	}

	if (tuslar[32] != 0) // e�er bo�luk tu�una bas�ld�ysa seri at�� yap�yor
	{
		mermiekle();
	}
}