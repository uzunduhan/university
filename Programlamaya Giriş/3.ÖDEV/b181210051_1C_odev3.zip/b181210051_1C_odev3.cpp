/****************************************************************************
**					SAKARYA �N�VERS�TES�
**			B�LG�SAYAR VE B�L���M B�L�MLER� FAK�LTES�
**				B�LG�SAYAR M�HEND�SL��� B�L�M�
**				  PROGRAMLAMAYA G�R��� DERS�
**
**				�DEV NUMARASI....: 3. �dev
**				��RENC� ADI......: Duhan UZUN
**				��RENC� NUMARASI.: B181210051
**				DERS GRUBU����...: 1C Grubu
****************************************************************************/
#include <iostream>
#include <iomanip>
#include <math.h>

using namespace std;

struct Islem
{
	int giris[5][5] = { 3,2,5,1,4,
	6,2,1,0,7,
	3,0,0,2,0,
	1,1,3,2,2,
	0,3,1,0,0 };

	int cekirdekBoyut;
	int cekirdekMatris[5][5];
	int sonucmatris[100][100];
	int sonucBoyut;
	int kaymaMiktari;
};

void matrisIslemi(Islem islem); //fonksiyonun prototipi

int main()
{
	Islem yapilacakIslem;

	int girisboyut;
	girisboyut = sqrt((sizeof(yapilacakIslem.giris) / sizeof(int))); // giri� matrisinin satir veya sutunun da ki eleman say�s�n� bulmaya yar�yor.

	cout << "cekirdek boyutu giriniz: ";
	cin >> yapilacakIslem.cekirdekBoyut;

	cout << "kayma miktarini giriniz: ";
	cin >> yapilacakIslem.kaymaMiktari;

	cout << endl;
	if (yapilacakIslem.kaymaMiktari == 0 || yapilacakIslem.cekirdekBoyut >= girisboyut)//kayma miktar� s�f�ra e�itse veya �ekirdek boyutu giri� boyutundan b�y�kse hata veriyor. 
	{
		cout << "bu islem yapilamaz..." << endl;
	}

	else
	{
		if ((girisboyut - yapilacakIslem.cekirdekBoyut) % yapilacakIslem.kaymaMiktari != 0) //e�er �ekirdek matrisi giri� matrisi �zerinde tam olarak kayam�yorsa hata veriyor.
		{
			cout << "bu islem yapilamaz..." << endl;
		}

		else // kay�yorsa i�lemleri yap�yor
		{
			yapilacakIslem.sonucBoyut = (girisboyut - yapilacakIslem.cekirdekBoyut) / yapilacakIslem.kaymaMiktari + 1;

			matrisIslemi(yapilacakIslem); //fonksiyonu �a��r�yor
		}
	}
	system("pause");
	return 0;
}
void matrisIslemi(Islem islem)
{
	//once cekirdek matrisinin elemanlarini aliyoruz
	for (int satir = 0; satir < islem.cekirdekBoyut; satir++)//0'dan �ekirdek boyutuna kadar sat�r� 1'er 1'er artt�r�r.
	{
		for (int sutun = 0; sutun < islem.cekirdekBoyut; sutun++)//0'dan �ekirdek boyutuna kadar sutunu 1'er 1'er artt�r�r.
		{
			cout << "cekirdek[" << satir << "]" << "[" << sutun << "]=";
			cin >> islem.cekirdekMatris[satir][sutun];
			cout << endl;
		}
	}
	//ardindan hesaplama islemine geciyoruz
	for (int satir = 0; satir < islem.sonucBoyut; satir++)//0'dan sonucun boyutuna kadar sat�r� 1'er 1'er artt�r�r.
	{
		for (int sutun = 0; sutun < islem.sonucBoyut; sutun++)//0'dan sonucun boyutuna kadar sutunu 1'er 1'er artt�r�r.
		{
			islem.sonucmatris[satir][sutun] = 0;

			for (int cekirdekSatir = 0; cekirdekSatir < islem.cekirdekBoyut; cekirdekSatir++)//0'dan �ekirdek boyutuna kadar �ekirdek sat�r� 1'er 1'er artt�r�r.
			{
				for (int cekirdekSutun = 0; cekirdekSutun < islem.cekirdekBoyut; cekirdekSutun++)//0'dan �ekirdek boyutuna kadar �ekirdek sutunu 1'er 1'er artt�r�r.
				{
					// i�lemler
					islem.sonucmatris[satir][sutun] += islem.cekirdekMatris[cekirdekSatir][cekirdekSutun]
						* islem.giris[satir*islem.kaymaMiktari + cekirdekSatir][sutun*islem.kaymaMiktari + cekirdekSutun];
				}
			}
		}
	}
	//sonuc bastirma islemi
	for (int sonucSatir = 0; sonucSatir < islem.sonucBoyut; sonucSatir++)//0'dan sonu� boyutuna kadar sonu� sat�r� 1'er 1'er artt�r�r.
	{
		for (int sonucSutun = 0; sonucSutun < islem.sonucBoyut; sonucSutun++)//0'dan sonu� boyutuna kadar sonu� sutunu 1'er 1'er artt�r�r.
		{
			cout << setw(6) << left << islem.sonucmatris[sonucSatir][sonucSutun]; //sonucu ekrana yazd�r�r.
		}
		cout << endl;
	}
}