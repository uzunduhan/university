/****************************************************************************
**					SAKARYA �N�VERS�TES�
**			B�LG�SAYAR VE B�L���M B�L�MLER� FAK�LTES�
**				B�LG�SAYAR M�HEND�SL��� B�L�M�
**				  PROGRAMLAMAYA G�R��� DERS�
**
**				�DEV NUMARASI....: 1. �dev, 2. k�s�m
**				��RENC� ADI......: Duhan UZUN
**				��RENC� NUMARASI.: B181210051
**				DERS GRUBU����...: C Grubu
****************************************************************************/

#include<iostream>
#include<iomanip> // setw i�in(setw hizalamaya yar�yor)
#include<string>

using namespace std;

int main()

{

	string kelime = "";

	cout << "kelime/kelimeler giriniz :\n";

	getline(cin, kelime); // bo�luklar� saymas� i�in


	int aSayisi = 0, eSayisi = 0, �Sayisi = 0, iSayisi = 0, oSayisi = 0, �Sayisi = 0, uSayisi = 0, �Sayisi = 0;



	for (int sayac = 0; kelime[sayac] != '\0'; ++sayac) // saya� s�f�r(null)' dan farkl� olana kadar artt�r
	{
		if ((kelime[sayac] == 'a') || (kelime[sayac] == 'A')) // a,A ise de�eri artt�r
			++aSayisi;

		else if ((kelime[sayac] == 'e') || (kelime[sayac] == 'E')) // e,E ise de�eri artt�r
			++eSayisi;

		else if ((kelime[sayac] == 'i') || (kelime[sayac] == 'I')) // i,�, ise de�eri artt�r
			++iSayisi;

		else if ((kelime[sayac] == 'o') || (kelime[sayac] == 'O')) // o,O ise de�eri artt�r
			++oSayisi;

		else if ((kelime[sayac] == 'u') || (kelime[sayac] == 'U')) // u,U ise de�eri artt�r
			++uSayisi;
	}

	cout << endl;

	int maksimumHarfSayisi = 0;

	if (aSayisi > maksimumHarfSayisi) // a max harften fazlaysa a harf dizinini artt�r
		maksimumHarfSayisi = aSayisi;

	if (eSayisi > maksimumHarfSayisi) // e max harften fazlaysa e harf dizinini artt�r
		maksimumHarfSayisi = eSayisi;

	if (iSayisi > maksimumHarfSayisi) // i max harften fazlaysa i harf dizinini artt�r
		maksimumHarfSayisi = iSayisi;

	if (oSayisi > maksimumHarfSayisi) // o max harften fazlaysa o harf dizinini artt�r
		maksimumHarfSayisi = oSayisi;

	if (uSayisi > maksimumHarfSayisi) // u max harften fazlaysa u harf dizinini artt�r
		maksimumHarfSayisi = uSayisi;


	cout << setw(6) << "H" << setw(8) << "TS" << setw(4);
	for (int sayac = 0; sayac < maksimumHarfSayisi; sayac++) // sayac var olan harf say�s�ndan fazla ise artt�r
	{
		cout << sayac + 1 << setw(4);
	}
	cout << endl;

	if (aSayisi > 0)
	{
		cout << setw(6) << "a" << setw(8) << aSayisi << setw(4);

		for (int sayac = 0; sayac < aSayisi; sayac++) // a say�s� saya�tan b�y�kse sayac� artt�r ve a yaz
		{
			cout << "a" << setw(4);
		}
		cout << endl;
	}

	if (eSayisi > 0)
	{
		cout << setw(6) << "e" << setw(8) << eSayisi << setw(4);

		for (int sayac = 0; sayac < eSayisi; sayac++) // e say�s� saya�tan b�y�kse sayac� artt�r ve e yaz
		{
			cout << "e" << setw(4);
		}
		cout << endl;
	}

	if (iSayisi > 0)
	{
		cout << setw(6) << "i" << setw(8) << iSayisi << setw(4);

		for (int sayac = 0; sayac < iSayisi; sayac++) // i say�s� saya�tan b�y�kse sayac� artt�r ve i yaz
		{
			cout << "i" << setw(4);
		}
		cout << endl;
	}

	if (oSayisi > 0)
	{
		cout << setw(6) << "o" << setw(8) << oSayisi << setw(4);

		for (int sayac = 0; sayac < oSayisi; sayac++) // o say�s� saya�tan b�y�kse sayac� artt�r ve o yaz
		{
			cout << "o" << setw(4);
		}
		cout << endl;
	}

	if (uSayisi > 0)
	{
		cout << setw(6) << "u" << setw(8) << uSayisi << setw(4);

		for (int sayac = 0; sayac < uSayisi; sayac++) // u say�s� saya�tan b�y�kse sayac� artt�r ve u yaz
		{
			cout << "u" << setw(4);
		}
		cout << endl;
	}


	system("pause");
	return 0;
}