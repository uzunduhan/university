/****************************************************************************
**					SAKARYA �N�VERS�TES�
**			B�LG�SAYAR VE B�L���M B�L�MLER� FAK�LTES�
**				B�LG�SAYAR M�HEND�SL��� B�L�M�
**				  PROGRAMLAMAYA G�R��� DERS�
**
**				�DEV NUMARASI....: 1. �dev, 1. k�s�m
**				��RENC� ADI......: Duhan UZUN
**				��RENC� NUMARASI.: B181210051
**				DERS GRUBU����...: C Grubu
****************************************************************************/

#include <iostream>

using namespace std;

int main()
{
	int iToplam, yildiz;
	int bosluk = 0;
	int MAX = 5;


	for (iToplam = MAX; iToplam > 0; iToplam--) // 5'den 0'a kadar azalt�r

	{

		for (yildiz = 0; yildiz < iToplam; yildiz++) // 0' dan 5'e kadar artt�rarak ekrana y�ld�z yazar 
		{
			cout << "*";
		}

		for (yildiz = 0; yildiz <= bosluk; yildiz++) // de�erince bo�luk atar
		{
			cout << " ";
		}

		for (yildiz = 0; yildiz < iToplam; yildiz++) // 0' dan 5'e kadar artt�rarak ekrana y�ld�z yazar 
		{
			cout << "*";
		}

		cout << "\n";
		bosluk += 2; // bo�luk say�s�n� 2 artt�r�r
	}


	for (iToplam = 0; iToplam < 6; iToplam++) // 0'dan 6'ya kadar artt�r�r

	{

		for (yildiz = 0; yildiz < iToplam; yildiz++) // 0'dan 6'ya kadar artt�rarak ekrana y�ld�z yazar 
		{
			cout << "*";
		}

		for (yildiz = 0; yildiz <= bosluk; yildiz++) // de�erince bo�luk atar
		{
			cout << " ";
		}

		for (yildiz = 0; yildiz < iToplam; yildiz++) // 0'dan 6'ya kadar artt�rarak ekrana y�ld�z yazar 
		{
			cout << "*";
		}

		cout << "\n";
		bosluk -= 2; // bo�luk say�s�n� 2 azalt�r

	}

	cout << endl;

	system("pause");
	return 0;
}