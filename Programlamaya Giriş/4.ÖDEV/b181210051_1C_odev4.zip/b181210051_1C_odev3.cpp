/****************************************************************************
**					SAKARYA �N�VERS�TES�
**			B�LG�SAYAR VE B�L���M B�L�MLER� FAK�LTES�
**				B�LG�SAYAR M�HEND�SL��� B�L�M�
**				  PROGRAMLAMAYA G�R��� DERS�
**
**				�DEV NUMARASI....: 4. �dev
**				��RENC� ADI......: Duhan UZUN
**				��RENC� NUMARASI.: B181210051
**				DERS GRUBU����...: 1C Grubu
****************************************************************************/

#include <iostream>
#include <cstring>
using namespace std;

class Sifre
{
public:
	Sifre(char *alfabe, char *sifre);
	Sifre();

	char* sifrele(char*);
	char* sifreCoz(char*);
	void sifreKelimesiAta(char*);

private:
	char* alfabe;
	char* sifreKelimesi;
};

Sifre::Sifre(char *alfabe, char*sifre)
{
	this->alfabe = alfabe;
	this->sifreKelimesi = sifre;
}

Sifre::Sifre()
{
	this->alfabe =(char*) "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
}

char* Sifre::sifrele(char* sifrelenecekDizi)
{
	char* sifrelenmisDizi = new char[strlen(sifrelenecekDizi) + 1];
	for (int i = 0; i < strlen(sifrelenecekDizi); i++)
	{
		char simdikiSifreHarfi = this->sifreKelimesi[i%strlen(this->sifreKelimesi)];
		int simdikiSifreHarfiDegeri;
		//simdiki sifre harfinin alfabede kacinci harfe denk geldigini buluyoruz
		for (int j = 0; j < strlen(this->alfabe); j++)
		{
			if (this->alfabe[j] == simdikiSifreHarfi)
			{
				simdikiSifreHarfiDegeri = j;
			}
		}
		char simdikiSifrelenecekHarf = sifrelenecekDizi[i];
		int simdikiSifrelenecekHarfDegeri;
		//simdiki sifrelenecek harfin alfabede kacinci harfe denk geldigini buluyoruz
		for (int j = 0; j < strlen(this->alfabe); j++)
		{
			if (this->alfabe[j] == simdikiSifrelenecekHarf)
			{
				simdikiSifrelenecekHarfDegeri = j;
			}
		}

		sifrelenmisDizi[i] = this->alfabe[(simdikiSifreHarfiDegeri + simdikiSifrelenecekHarfDegeri + 1) % strlen(this->alfabe)];

	}
	sifrelenmisDizi[strlen(sifrelenecekDizi)] = '\0';
	return sifrelenmisDizi;
}

char* Sifre::sifreCoz(char* sifrelenmisDizi)
{
	char* sifresiCozulmusDizi = new char[strlen(sifrelenmisDizi) + 1];
	for (int i = 0; i < strlen(sifrelenmisDizi); i++)
	{
		char simdikiSifreHarfi = this->sifreKelimesi[i%strlen(this->sifreKelimesi)];
		int simdikiSifreHarfiDegeri;
		//simdiki sifre harfinin alfabede kacinci harfe denk geldigini buluyoruz
		for (int j = 0; j < strlen(this->alfabe); j++)
		{
			if (this->alfabe[j] == simdikiSifreHarfi)
			{
				simdikiSifreHarfiDegeri = j;
			}
		}
		char simdikiSifresiCozulecekHarf = sifrelenmisDizi[i];
		int simdikiSifresiCozulecekHarfDegeri;
		//simdiki sifresi cozulecek harfin alfabede kacinci harfe denk geldigini buluyoruz
		for (int j = 0; j < strlen(this->alfabe); j++)
		{
			if (this->alfabe[j] == simdikiSifresiCozulecekHarf)
			{
				simdikiSifresiCozulecekHarfDegeri = j;
			}
		}
		sifresiCozulmusDizi[i] = this->alfabe[(simdikiSifresiCozulecekHarfDegeri - simdikiSifreHarfiDegeri - 1 + strlen(this->alfabe)) % strlen(this->alfabe)];
	}
	sifresiCozulmusDizi[strlen(sifrelenmisDizi)] = '\0';
	return sifresiCozulmusDizi;
}

void Sifre::sifreKelimesiAta(char* gelenSifreKelimesi)
{
	sifreKelimesi = gelenSifreKelimesi;
}
int main()
{
	Sifre sifreObjesi;
	sifreObjesi.sifreKelimesiAta((char*)"BSM");
	char * sifrelenecekMetin = sifreObjesi.sifrele((char*)"SAKARYAUNIVERSITESI");
	cout << sifrelenecekMetin << endl;
	cout << sifreObjesi.sifreCoz(sifrelenecekMetin) << endl;
	system("pause");
	return 0;
}