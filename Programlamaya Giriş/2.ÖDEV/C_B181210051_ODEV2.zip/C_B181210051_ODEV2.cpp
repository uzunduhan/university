/****************************************************************************
**					SAKARYA �N�VERS�TES�
**			B�LG�SAYAR VE B�L���M B�L�MLER� FAK�LTES�
**				B�LG�SAYAR M�HEND�SL��� B�L�M�
**				  PROGRAMLAMAYA G�R��� DERS�
**
**				�DEV NUMARASI....: 2. �dev
**				��RENC� ADI......: Duhan UZUN
**				��RENC� NUMARASI.: B181210051
**				DERS GRUBU����...: C Grubu
****************************************************************************/

#include <iostream>
#include <iomanip>
#include <ctime>

using namespace std;

const int maxSatir = 5;
const int maxSutun = 10;
char harf[maxSatir][maxSutun];
char harfy;

char yeniatama(int x) // bir b�y�k bir k���k harf atamak i�in char fonksiyonu
{
	if (x % 2 == 0)
	{
		harfy = rand() % 26 + 65; // b�y�k harfleri olu�turur
	}
	else
	{
		harfy = rand() % 26 + 97; // k���k harfleri olu�turur.
	}
	return harfy;
}

int main()
{
	srand(time(0)); // zaman� s�f�rlar
	const int maxSatir = 5;
	const int maxSutun = 10;
	char harf[maxSatir][maxSutun];
	int kontrol = 1;

	cout << "tekrarsiz ve rastgele dizi" << endl;

	for (int satir = 0; satir < maxSatir; satir++) // 5 satir olu�turur
	{
		for (int sutun = 0; sutun < maxSutun; sutun++) // 10 sutun olu�turur
		{
			int kontrol = 0;
			while (kontrol == 0)
			{
				kontrol = 1;
				char a = yeniatama(sutun);
				for (int satir2 = satir; satir2 >= 0; satir2--) // 5'den-0'a kadar sat�r� azalt�r
				{
					for (int sutun2 = 0; sutun2 < maxSutun; sutun2++) // 0'dan 10'a kadar artt�r�r
					{
						if (harf[satir2][sutun2] == a) // e�itse yoksay
						{
							kontrol = 0;
							break;
						}
					}
				}
				if (kontrol == 1) // de�ilse yazd�r
				{
					harf[satir][sutun] = a;
					break;
				}
			}
			cout << harf[satir][sutun] << "      "; // ekrana matrisi kar���k ve tekrars�z �ekide yazd�r�r
		}
		cout << endl << endl;
	}


	cout << "siralanmis dizi" << endl;

	int temp;
	int satir, sutun, satir2, sutun2;

	for (satir = 0; satir < maxSatir; satir++) //5 satir olu�turur
	{
		for (sutun = 0; sutun < maxSutun; sutun++) // 10 sutun olu�turur
		{
			for (satir2 = 0; satir2 < maxSatir; satir2++) // kar��la�t�rmak i�in ikinci bir matrisin satirini olu�turur.
			{
				for (sutun2 = 0; sutun2 < maxSutun; sutun2++) // kar��la�t�rmak i�in ikinci bir matrisin sutunu olu�turur.
				{
					if (harf[satir][sutun] < harf[satir2][sutun2 + 1]) // bir eleman bir sonraki elemandan k���kse yer de�i�tirir.
					{
						temp = harf[satir][sutun];
						harf[satir][sutun] = harf[satir2][sutun2 + 1];
						harf[satir2][sutun2 + 1] = temp;
					}
				}
			}
		}
	}

	for (satir2 = 0; satir2 < maxSatir; satir2++) // 0'dan 5'e  kadar satiri artt�r�r.
	{
		for (sutun2 = 0; sutun2 < maxSutun; sutun2++) // 0'dan 10 'a kadar sutunu artt�r�r.
		{
			cout << harf[satir2][sutun2] << "      "; // ekrana matrisi s�ral� ve tekrars�z bir �ekilde yaz�r�r.

		}cout << endl << endl;
	}


	system("pause");
	return 0;
}